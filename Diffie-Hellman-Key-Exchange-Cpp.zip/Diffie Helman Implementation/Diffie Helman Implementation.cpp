#include <iostream>
#include <cmath>

using namespace std;

// Function to check if a number is prime
bool isPrime(int n) 
{
    if (n <= 1) return false;
    if (n <= 3) return true;

    if (n % 2 == 0 || n % 3 == 0) return false;

    for (int i = 5; i * i <= n; i = i + 6)
        if (n % i == 0 || n % (i + 2) == 0)
        {
            return false;
        }

    return true;
}

// Function to calculate (base^exp) % modulus efficiently using modular exponentiation
int modExp(int base, int exp, int modulus) 
{
    int result = 1;

    base = base % modulus;

    while (exp > 0) 
	{
        if (exp % 2 == 1) 
		{
            result = (result * base) % modulus;
        }

        exp = exp >> 1;
        base = (base * base) % modulus;
    }

    return result;
}

// Function to calculate public key based on private key, generator, and prime modulus
int calculatePublicKey(int privateKey, int generator, int primeModulus) 
{
    return modExp(generator, privateKey, primeModulus);
}

// Function to perform Diffie-Hellman key exchange
void diffieHelman(int p, int g, int a, int b) 
{
    // Calculate public keys for Alice and Bob
    int A = calculatePublicKey(a, g, p); // Public key for Alice
    int B = calculatePublicKey(b, g, p); // Public key for Bob

    // Alice and Bob exchange public keys A and B
    // Alice computes shared secret S = B^a mod p
    int S_Alice = modExp(B, a, p);

    // Bob computes shared secret S = A^b mod p
    int S_Bob = modExp(A, b, p);

    // Both Alice and Bob now have the same shared secret, which can be used for encryption or other purposes
    cout << "\n\n\t\tShared Secret key computed by Alice: " << S_Alice << endl;
    cout << "\t\tShared Secret key computed by Bob: " << S_Bob << endl;
    
    cout << "\n\n-------------------------------------------------------------------------------------------" << endl;

}

int main() 
{
   cout << "\n\n------------------------  Diffie Helman Key Exchange Implementation  ---------------------\n\n";

    // Get prime modulus from user
    int p;

    do 
	{
        cout << "\n\n\t\tEnter the prime modulus (p) greater than 2: ";
        cin >> p;    
    } 
	while (!isPrime(p) || p <= 2);

    // Get generator from user
    int g;

    do 
	{
        cout << "\t\tEnter the generator (g) between 1 and " << p - 1 << ": ";
        cin >> g;
    } 
	while (g <= 1 || g >= p - 1);

    // Private keys for Alice and Bob
    int a, b;

    cout << "\n\n\t\tEnter Alice's private key (a): ";
    cin >> a;

    cout << "\t\tEnter Bob's private key (b): ";
    cin >> b;

    cout << "\n\n\t\tThe private keys of Alice and Bob are: " << a << " & " << b << endl << endl;

    // Perform Diffie-Helman key exchange
    diffieHelman(p, g, a, b);

    return 0;
}
